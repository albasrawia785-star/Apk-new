package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val appDao: AppDao) {
    // Users
    suspend fun getUser(username: String): User? = appDao.getUser(username)
    fun getAllUsersFlow(): Flow<List<User>> = appDao.getAllUsersFlow()
    suspend fun insertUser(user: User) = appDao.insertUser(user)
    suspend fun updateUser(user: User) = appDao.updateUser(user)
    suspend fun deleteUser(user: User) = appDao.deleteUser(user)

    // Drugs
    fun getAllDrugsFlow(): Flow<List<Drug>> = appDao.getAllDrugsFlow()
    suspend fun getDrugByBarcode(barcode: String): Drug? = appDao.getDrugByBarcode(barcode)
    suspend fun getDrugById(id: Int): Drug? = appDao.getDrugById(id)
    suspend fun insertDrug(drug: Drug) = appDao.insertDrug(drug)
    suspend fun updateDrug(drug: Drug) = appDao.updateDrug(drug)
    suspend fun deleteDrug(drug: Drug) = appDao.deleteDrug(drug)
    suspend fun getDrugsCount(): Int = appDao.getDrugsCount()

    // Companies
    fun getAllCompaniesFlow(): Flow<List<Company>> = appDao.getAllCompaniesFlow()
    suspend fun insertCompany(company: Company) = appDao.insertCompany(company)
    suspend fun updateCompany(company: Company) = appDao.updateCompany(company)
    suspend fun deleteCompany(company: Company) = appDao.deleteCompany(company)

    // Categories
    fun getAllCategoriesFlow(): Flow<List<Category>> = appDao.getAllCategoriesFlow()
    suspend fun insertCategory(category: Category) = appDao.insertCategory(category)
    suspend fun updateCategory(category: Category) = appDao.updateCategory(category)
    suspend fun deleteCategory(category: Category) = appDao.deleteCategory(category)

    // Sales
    fun getAllSalesBillsFlow(): Flow<List<SaleBill>> = appDao.getAllSalesBillsFlow()
    suspend fun insertSaleBill(saleBill: SaleBill) = appDao.insertSaleBill(saleBill)
    suspend fun deleteSaleBill(saleBill: SaleBill) = appDao.deleteSaleBill(saleBill)

    // Logs
    fun getAllLogsFlow(): Flow<List<OperationLog>> = appDao.getAllLogsFlow()
    suspend fun insertLog(log: OperationLog) = appDao.insertLog(log)

    // Settings
    suspend fun getSetting(key: String): SystemSetting? = appDao.getSetting(key)
    fun getSettingFlow(key: String): Flow<SystemSetting?> = appDao.getSettingFlow(key)
    suspend fun insertSetting(setting: SystemSetting) = appDao.insertSetting(setting)
}
