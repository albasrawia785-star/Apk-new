package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.*
import com.example.ui.components.VisualBarcode
import kotlinx.coroutines.launch
import java.util.UUID

// --- 1. LOGIN SCREEN ---
@Composable
fun LoginView(
    mustChangePasswordUser: User?,
    onLogin: (String, String) -> Unit,
    onChangePassword: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    // Change password state
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var changePasswordError by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        // Decorative background elements for premium feel
        Box(
            modifier = Modifier
                .size(300.dp)
                .offset(x = (-100).dp, y = (-120).dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
        )
        Box(
            modifier = Modifier
                .size(200.dp)
                .offset(x = 120.dp, y = 180.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.05f))
        )

        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (mustChangePasswordUser != null) {
                    // Force Password Change View
                    Icon(
                        imageVector = Icons.Default.LockReset,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "تغيير كلمة المرور الإلزامي",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "هذا هو أول تسجيل دخول لك بصفتك (${mustChangePasswordUser.username}). يرجى تحديد كلمة مرور آمنة للمتابعة.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("تأكيد كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    if (changePasswordError.isNotEmpty()) {
                        Text(
                            text = changePasswordError,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (newPassword.isBlank()) {
                                changePasswordError = "لا يمكن أن تكون كلمة المرور فارغة!"
                            } else if (newPassword != confirmPassword) {
                                changePasswordError = "كلمتا المرور غير متطابقتين!"
                            } else if (newPassword == "ali") {
                                changePasswordError = "يرجى اختيار كلمة مرور مختلفة عن الافتراضية 'ali'!"
                            } else {
                                onChangePassword(mustChangePasswordUser.username, newPassword)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("حفظ كلمة المرور والدخول للنظام", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Standard Login View
                    Text(
                        text = "💊",
                        fontSize = 54.sp
                    )
                    Text(
                        text = "دوائي",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "نظام إدارة مخازن الصيدليات والأدوية في العراق",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 20.dp)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم المستخدم") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Text(
                        text = "💡 تسجيل الدخول الافتراضي للمرة الأولى:\nاسم المستخدم: ali | كلمة المرور: ali",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (username.isNotBlank() && password.isNotBlank()) {
                                onLogin(username.trim(), password)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("تسجيل الدخول الآمن", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 2. DASHBOARD TAB ---
@Composable
fun DashboardScreen(
    allDrugs: List<Drug>,
    allCompanies: List<Company>,
    allCategories: List<Category>,
    allSalesBills: List<SaleBill>,
    onQuickSellClick: () -> Unit
) {
    // Analytics calculations
    val totalDrugs = allDrugs.size
    val totalCompanies = allCompanies.size
    val totalCategories = allCategories.size
    val stockValue = allDrugs.sumOf { it.quantity * it.purchasePrice }
    val expiredCount = allDrugs.count { !it.isArchived && isMedicineExpired(it.expiryDate) }
    val lowStockCount = allDrugs.count { !it.isArchived && it.quantity <= it.minLimit && it.quantity > 0 }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Welcome Header Card
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "أهلاً بك في لوحة تحكم دوائي",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "النظام يعمل دون اتصال إنترنت 100% ويحفظ بيانات الصيدلية بأمان محلياً.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onQuickSellClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("بيع سريع", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            // Hero Gradient Value Card (Stock Value Hero Card)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF006A6A), // Teal
                                Color(0xFF004D4D)  // Dark Teal
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Text(
                        text = "إجمالي قيمة المخزون",
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = formatIraqiDinar(stockValue),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Total Drugs
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("الأدوية", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(totalDrugs.toString(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        // Total Companies
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("الشركات", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(totalCompanies.toString(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        // Total Categories
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("التصنيفات", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(totalCategories.toString(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        item {
            // Critical Stats Grid (Expired and Low Stock Cards in Natural Tones design)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Expired Drugs Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            color = if (expiredCount > 0) Color(0xFFFEF2F2) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    color = if (expiredCount > 0) Color(0xFFEF4444) else Color(0xFF94A3B8),
                                    shape = RoundedCornerShape(10.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Dangerous,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "منتهي الصلاحية",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (expiredCount > 0) Color(0xFF991B1B) else Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = expiredCount.toString(),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = if (expiredCount > 0) Color(0xFF7F1D1D) else Color(0xFF1E293B)
                        )
                    }
                }

                // Low Stock Drugs Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            color = if (lowStockCount > 0) Color(0xFFFFF7ED) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    color = if (lowStockCount > 0) Color(0xFFF97316) else Color(0xFF94A3B8),
                                    shape = RoundedCornerShape(10.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "كمية منخفضة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (lowStockCount > 0) Color(0xFF9A3412) else Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = lowStockCount.toString(),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = if (lowStockCount > 0) Color(0xFF7C2D12) else Color(0xFF1E293B)
                        )
                    }
                }
            }
        }

        item {
            // Recent Transactions Section Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "آخر المبيعات المسجلة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF004D4D)
                )
            }
        }

        if (allSalesBills.isEmpty()) {
            item {
                OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("لا توجد مبيعات مسجلة حتى الآن", color = Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            items(allSalesBills.take(5)) { bill ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color(0xFF006A6A).copy(alpha = 0.08f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = Color(0xFF006A6A),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = bill.drugName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = "الفاتورة: ${bill.invoiceNumber} • الكمية: ${bill.quantity}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = formatIraqiDinar(bill.totalPrice),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF006A6A)
                            )
                            Text(
                                text = formatTimestamp(bill.timestamp),
                                fontSize = 10.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    colorHighlight: Color = MaterialTheme.colorScheme.primary
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = colorHighlight.copy(alpha = 0.8f),
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = colorHighlight,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color.Gray
            )
        }
    }
}

// --- 3. DRUGS (INVENTORY) TAB ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrugsScreen(
    allDrugs: List<Drug>,
    allCompanies: List<Company>,
    allCategories: List<Category>,
    currentUser: User,
    onAddDrugClick: () -> Unit,
    onEditDrugClick: (Drug) -> Unit,
    onDeleteDrugClick: (Drug) -> Unit,
    onGenerateBarcode: (Int) -> Unit
) {
    var searchVal by remember { mutableStateOf("") }
    var selectedCatFilter by remember { mutableStateOf<String?>(null) }
    var selectedCompFilter by remember { mutableStateOf<String?>(null) }
    
    // Status filters
    var filterExpiredOnly by remember { mutableStateOf(false) }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    // Toggle management area expansion
    var isManagementExpanded by remember { mutableStateOf(false) }

    // Search and filter logic applied to database list
    val filteredDrugs = allDrugs.filter { drug ->
        val matchesSearch = drug.arabicName.contains(searchVal, ignoreCase = true) ||
                drug.scientificName.contains(searchVal, ignoreCase = true) ||
                drug.barcode.contains(searchVal) ||
                drug.companyName.contains(searchVal, ignoreCase = true)
        
        val matchesCat = selectedCatFilter == null || drug.categoryName == selectedCatFilter
        val matchesComp = selectedCompFilter == null || drug.companyName == selectedCompFilter
        
        val matchesExpired = !filterExpiredOnly || isMedicineExpired(drug.expiryDate)
        val matchesLowStock = !filterLowStockOnly || (drug.quantity <= drug.minLimit && drug.quantity > 0)

        matchesSearch && matchesCat && matchesComp && matchesExpired && matchesLowStock
    }

    Scaffold(
        floatingActionButton = {
            if (currentUser.canAddDrug) {
                FloatingActionButton(
                    onClick = onAddDrugClick,
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Drug", tint = Color.White)
                }
            }
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchVal,
                onValueChange = { searchVal = it },
                placeholder = { Text("ابحث باسم الدواء، الاسم العلمي، الباركود...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            // Dynamic filter options
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = filterExpiredOnly,
                    onClick = {
                        filterExpiredOnly = !filterExpiredOnly
                        if (filterExpiredOnly) filterLowStockOnly = false
                    },
                    label = { Text("المنتهي فقط", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.errorContainer
                    )
                )
                FilterChip(
                    selected = filterLowStockOnly,
                    onClick = {
                        filterLowStockOnly = !filterLowStockOnly
                        if (filterLowStockOnly) filterExpiredOnly = false
                    },
                    label = { Text("قريب النفاد", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                )
                
                Spacer(modifier = Modifier.weight(1f))

                // Custom collapse for Company/Category rapid config
                TextButton(
                    onClick = { isManagementExpanded = !isManagementExpanded },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(
                        imageVector = if (isManagementExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إدارة التصنيفات والشركات", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            AnimatedVisibility(visible = isManagementExpanded) {
                ConfigManagerSubPanel(allCompanies, allCategories)
            }

            // Quick Category Filter Scrollbar
            Text(
                text = "الفلترة حسب التصنيف العلاجي:",
                fontSize = 11.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Bold
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedCatFilter == null,
                    onClick = { selectedCatFilter = null },
                    label = { Text("الكل", fontSize = 10.sp) }
                )
                allCategories.take(6).forEach { cat ->
                    FilterChip(
                        selected = selectedCatFilter == cat.name,
                        onClick = { selectedCatFilter = cat.name },
                        label = { Text(cat.name, fontSize = 10.sp) }
                    )
                }
            }

            HorizontalDivider()

            // List of Medicines
            if (filteredDrugs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inbox,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد أدوية مطابقة للبحث أو الفلترة",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredDrugs) { drug ->
                        var isExpanded by remember { mutableStateOf(false) }
                        
                        ElevatedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isExpanded = !isExpanded },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = drug.arabicName,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = "(${drug.strength})",
                                                fontSize = 12.sp,
                                                color = Color.Gray
                                            )
                                        }
                                        Text(
                                            text = drug.scientificName,
                                            fontSize = 12.sp,
                                            color = Color.Gray,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "الكمية: ${drug.quantity}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (drug.quantity <= drug.minLimit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = formatIraqiDinar(drug.salePrice),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text(drug.categoryName, fontSize = 9.sp) }
                                    )
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text(drug.companyName, fontSize = 9.sp) }
                                    )
                                    if (isMedicineExpired(drug.expiryDate)) {
                                        SuggestionChip(
                                            onClick = {},
                                            label = { Text("⚠️ منتهي الصلاحية", fontSize = 9.sp, color = MaterialTheme.colorScheme.error) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                                            )
                                        )
                                    }
                                }

                                AnimatedVisibility(visible = isExpanded) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 12.dp)
                                    ) {
                                        HorizontalDivider(modifier = Modifier.padding(bottom = 8.dp))
                                        
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(text = "رقم الوجبة/التشغيلة: ${drug.batchNumber}", fontSize = 12.sp)
                                            Text(text = "سعر الشراء: ${formatIraqiDinar(drug.purchasePrice)}", fontSize = 12.sp)
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(text = "تاريخ الإنتاج: ${drug.productionDate}", fontSize = 12.sp)
                                            Text(text = "تاريخ الانتهاء: ${drug.expiryDate}", fontSize = 12.sp)
                                        }
                                        Text(text = "الباركود المسجل: ${drug.barcode}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        if (drug.notes.isNotEmpty()) {
                                            Text(text = "ملاحظات الدواء: ${drug.notes}", fontSize = 12.sp, color = Color.Gray)
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Drawn Sticker Barcode widget
                                        VisualBarcode(
                                            barcode = drug.barcode.ifEmpty { "0000000000000" },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp)
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            if (currentUser.canEditDrug) {
                                                OutlinedButton(
                                                    onClick = { onEditDrugClick(drug) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("تعديل", fontSize = 12.sp)
                                                }
                                            }
                                            if (currentUser.canDeleteDrug) {
                                                OutlinedButton(
                                                    onClick = { onDeleteDrugClick(drug) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("حذف", fontSize = 12.sp)
                                                }
                                            }
                                            if (drug.barcode.isBlank() || drug.barcode.startsWith("TEMP-")) {
                                                Button(
                                                    onClick = { onGenerateBarcode(drug.id) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text("إنشاء باركود", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Subpanel inside inventory to easily register raw companies and categories
@Composable
fun ConfigManagerSubPanel(
    allCompanies: List<Company>,
    allCategories: List<Category>
) {
    var newCompText by remember { mutableStateOf("") }
    var newCatText by remember { mutableStateOf("") }

    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(text = "إضافة سريعة للتصنيفات والشركات يدويًا:", fontSize = 13.sp, fontWeight = FontWeight.Bold)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = newCatText,
                    onValueChange = { newCatText = it },
                    placeholder = { Text("اسم التصنيف الجديد") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )
                Button(
                    onClick = {
                        if (newCatText.isNotBlank()) {
                            scope.launch {
                                try {
                                    db.appDao().insertCategory(Category(name = newCatText.trim()))
                                    newCatText = ""
                                } catch (e: Exception) { e.printStackTrace() }
                            }
                        }
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("أضف")
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = newCompText,
                    onValueChange = { newCompText = it },
                    placeholder = { Text("اسم الشركة المصنعة") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )
                Button(
                    onClick = {
                        if (newCompText.isNotBlank()) {
                            scope.launch {
                                try {
                                    db.appDao().insertCompany(Company(name = newCompText.trim()))
                                    newCompText = ""
                                } catch (e: Exception) { e.printStackTrace() }
                            }
                        }
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("أضف")
                }
            }
        }
    }
}

// --- 4. BARCODE POS ACTIONS MENU ---
@Composable
fun POSScreen(
    allDrugs: List<Drug>,
    onActionSelected: (ScannerAction) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "⚡ نظام العمليات السريعة بالباركود",
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Text(
            text = "اختر العملية المطلوبة، ستفتح الكاميرا فوراً لقراءة باركود علبة الدواء.",
            fontSize = 12.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp, top = 4.dp)
        )

        POSActionCard(
            title = "بيع دواء للمريض",
            subtitle = "مسح باركود العلبة لبيعها وخصمها فوراً من مخزون الصيدلية",
            icon = Icons.Default.PointOfSale,
            colorHighlight = MaterialTheme.colorScheme.primary,
            onClick = { onActionSelected(ScannerAction.SELL) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        POSActionCard(
            title = "شراء وإدخال كمية للمستودع",
            subtitle = "زيادة عدد علب دواء مسجل مسبقاً في مخزونك بسرعة",
            icon = Icons.Default.AddBusiness,
            colorHighlight = MaterialTheme.colorScheme.secondary,
            onClick = { onActionSelected(ScannerAction.ADD) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        POSActionCard(
            title = "البحث والاستعلام السريع",
            subtitle = "عرض بيانات وتفاصيل الدواء وسعره وتاريخ صلاحيته",
            icon = Icons.Default.Search,
            colorHighlight = MaterialTheme.colorScheme.tertiary,
            onClick = { onActionSelected(ScannerAction.SEARCH) }
        )
    }
}

@Composable
fun POSActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    colorHighlight: Color,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(colorHighlight.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = colorHighlight, modifier = Modifier.size(24.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text(text = subtitle, fontSize = 11.sp, color = Color.Gray)
            }
            Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = null, tint = Color.LightGray)
        }
    }
}

// --- 5. REPORTS AND LOGS ---
@Composable
fun ReportsScreen(
    allDrugs: List<Drug>,
    allSalesBills: List<SaleBill>,
    allLogs: List<OperationLog>,
    currentUser: User,
    onDeleteSaleBill: (SaleBill) -> Unit
) {
    var selectedReportTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Report Selector tabs
        ScrollableTabRow(selectedTabIndex = selectedReportTab) {
            Tab(selected = selectedReportTab == 0, onClick = { selectedReportTab = 0 }, text = { Text("المخزون", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedReportTab == 1, onClick = { selectedReportTab = 1 }, text = { Text("الفواتير", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedReportTab == 2, onClick = { selectedReportTab = 2 }, text = { Text("الأرباح", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedReportTab == 3, onClick = { selectedReportTab = 3 }, text = { Text("النواقص والصلاحيات", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
            Tab(selected = selectedReportTab == 4, onClick = { selectedReportTab = 4 }, text = { Text("سجل التدقيق", fontSize = 12.sp, fontWeight = FontWeight.Bold) })
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    simulateExport(context, "Excel", compileExcelReportText(allDrugs, allSalesBills))
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصدير Excel", fontSize = 12.sp)
            }
            Button(
                onClick = {
                    simulateExport(context, "PDF", compilePDFReportText(allDrugs, allSalesBills))
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصدير PDF", fontSize = 12.sp)
            }
        }

        HorizontalDivider()

        when (selectedReportTab) {
            0 -> {
                // Stock Report
                val stockValue = allDrugs.sumOf { it.quantity * it.purchasePrice }
                val saleValueExpected = allDrugs.sumOf { it.quantity * it.salePrice }
                Text(text = "📊 تفاصيل المخزون العام:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "القيمة الإجمالية للمخزون (سعر الشراء): ${formatIraqiDinar(stockValue)}")
                        Text(text = "القيمة المتوقعة للمبيعات (سعر البيع): ${formatIraqiDinar(saleValueExpected)}")
                        Text(text = "الأرباح الكامنة المتوقعة بالمستودع: ${formatIraqiDinar(saleValueExpected - stockValue)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(allDrugs) { drug ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = drug.arabicName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "${drug.quantity} حبة x ${formatIraqiDinar(drug.purchasePrice)}", fontSize = 12.sp)
                        }
                    }
                }
            }
            1 -> {
                // Invoices / Sales bills list
                Text(text = "🧾 فواتير المبيعات المسجلة:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (allSalesBills.isEmpty()) {
                        item { Text("لا توجد فواتير بيع مسجلة.", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                    } else {
                        items(allSalesBills) { bill ->
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = "فاتورة: ${bill.invoiceNumber}", fontWeight = FontWeight.Bold)
                                        Text(text = formatTimestamp(bill.timestamp), fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = "${bill.drugName} (الكمية: ${bill.quantity})", fontSize = 13.sp)
                                        Text(text = formatIraqiDinar(bill.totalPrice), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Text(text = "البائع: ${bill.username}", fontSize = 11.sp, color = Color.Gray)

                                    if (currentUser.role == "ADMIN") {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Button(
                                            onClick = { onDeleteSaleBill(bill) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.align(Alignment.End).height(32.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp)
                                        ) {
                                            Text("إلغاء البيع واسترجاع الكمية", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // Profit report
                val totalRevenue = allSalesBills.sumOf { it.totalPrice }
                // Calculate actual purchase cost for items sold
                val totalCost = allSalesBills.sumOf { bill ->
                    val drug = allDrugs.find { it.id == bill.drugId }
                    val purchaseUnitPrice = drug?.purchasePrice ?: 0.0
                    bill.quantity * purchaseUnitPrice
                }
                val netProfit = totalRevenue - totalCost

                Text(text = "📈 تقرير أرباح المبيعات الفعلية:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "إجمالي مبالغ المبيعات الكلية: ${formatIraqiDinar(totalRevenue)}", fontSize = 15.sp)
                        Text(text = "تكلفة شراء الأدوية المباعة الكلية: ${formatIraqiDinar(totalCost)}", fontSize = 15.sp)
                        HorizontalDivider()
                        Text(
                            text = "صافي أرباح المبيعات: ${formatIraqiDinar(netProfit)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
            3 -> {
                // Low Stock and Expiry Warning
                val expiredDrugs = allDrugs.filter { isMedicineExpired(it.expiryDate) && !it.isArchived }
                val lowStockDrugs = allDrugs.filter { it.quantity <= it.minLimit && it.quantity > 0 && !it.isArchived }

                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Text(text = "⚠️ أدوية منتهية الصلاحية (${expiredDrugs.size}):", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                    }
                    if (expiredDrugs.isEmpty()) {
                        item { Text("لا توجد أدوية منتهية الصلاحية في المستودع.", color = Color.Gray, fontSize = 12.sp) }
                    } else {
                        items(expiredDrugs) { drug ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = drug.arabicName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "انتهى بتاريخ: ${drug.expiryDate}", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }
                    }

                    item {
                        Text(text = "⚠️ أدوية منخفضة الكمية وتوشك على النفاد (${lowStockDrugs.size}):", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                    }
                    if (lowStockDrugs.isEmpty()) {
                        item { Text("جميع الأدوية متوفرة بكميات كافية.", color = Color.Gray, fontSize = 12.sp) }
                    } else {
                        items(lowStockDrugs) { drug ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = drug.arabicName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "المتوفر: ${drug.quantity} (الحد الأدنى: ${drug.minLimit})", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            4 -> {
                // Operations Log
                Text(text = "🕵️ سجل العمليات وتدقيق الأمان:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (allLogs.isEmpty()) {
                        item { Text("لا توجد عمليات مسجلة.", color = Color.Gray) }
                    } else {
                        items(allLogs) { log ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${log.operationType} - ${log.drugName.ifEmpty { "عملية عامة" }}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(text = log.details, fontSize = 12.sp)
                                    Text(text = "المستخدم: ${log.username}", fontSize = 10.sp, color = Color.Gray)
                                }
                                Text(
                                    text = formatTimestamp(log.timestamp),
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Generate text report mock for PDF/Excel sharing
fun compileExcelReportText(drugs: List<Drug>, sales: List<SaleBill>): String {
    val sb = StringBuilder()
    sb.append("تقرير صيدلية دوائي - تصدير Excel CSV\n")
    sb.append("اسم الدواء,الاسم العلمي,الكمية,سعر الشراء,سعر البيع,تاريخ الصلاحية,الباركود\n")
    for (d in drugs) {
        sb.append("${d.arabicName},${d.scientificName},${d.quantity},${d.purchasePrice},${d.salePrice},${d.expiryDate},${d.barcode}\n")
    }
    return sb.toString()
}

fun compilePDFReportText(drugs: List<Drug>, sales: List<SaleBill>): String {
    val sb = StringBuilder()
    sb.append("--------------------------------------------------\n")
    sb.append("               تقرير صيدلية دوائي العام           \n")
    sb.append("--------------------------------------------------\n")
    sb.append("عدد الأدوية المسجلة: ${drugs.size}\n")
    sb.append("قيمة الأصول بسعر الشراء: ${drugs.sumOf { it.quantity * it.purchasePrice }} د.ع\n")
    sb.append("\nقائمة الأدوية المتوفرة:\n")
    for (d in drugs) {
        sb.append("- ${d.arabicName} | الكمية: ${d.quantity} | تاريخ الصلاحية: ${d.expiryDate}\n")
    }
    return sb.toString()
}

fun simulateExport(context: Context, formatName: String, data: String) {
    try {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Pharmacy Report", data)
        clipboard.setPrimaryClip(clip)
        
        // Android share sheet launcher mock
        val sendIntent: android.content.Intent = android.content.Intent().apply {
            action = android.content.Intent.ACTION_SEND
            putExtra(android.content.Intent.EXTRA_TEXT, data)
            type = "text/plain"
        }
        val shareIntent = android.content.Intent.createChooser(sendIntent, "مشاركة تقرير صيدلية دوائي")
        shareIntent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

// --- 6. SETTINGS & SYSTEM UTILITIES ---
@Composable
fun SettingsScreen(
    allUsers: List<User>,
    currentUser: User,
    pharmacyName: String,
    logoIndex: Int,
    onUpdatePharmacyName: (String) -> Unit,
    onUpdateLogo: (Int) -> Unit,
    onAddUser: (User) -> Unit,
    onUpdateUser: (User) -> Unit,
    onDeleteUser: (User) -> Unit,
    onExportBackup: ((String) -> Unit) -> Unit,
    onImportBackup: (String, (Boolean, String) -> Unit) -> Unit,
    onUpdatePassword: (String, String) -> Unit
) {
    var storeNameText by remember { mutableStateOf(pharmacyName) }
    var oldPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }

    // User addition
    var isUserPanelExpanded by remember { mutableStateOf(false) }
    var newUsername by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var newUserRole by remember { mutableStateOf("EMPLOYEE") } // "ADMIN", "EMPLOYEE"

    // Backup restore string
    var backupRestoreJsonText by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "🛠️ إعدادات النظام وتخصيص الصيدلية:", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        // 1. Branding Settings
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "تخصيص الهوية التجارية:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(
                    value = storeNameText,
                    onValueChange = { storeNameText = it },
                    label = { Text("اسم مخزن الأدوية / الصيدلية") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onUpdatePharmacyName(storeNameText) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حفظ الاسم الجديد")
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(text = "شعار التطبيق النشط:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("💊", "🏥", "🧪", "🩺", "💚").forEachIndexed { index, item ->
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (logoIndex == index) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                .clickable { onUpdateLogo(index) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = item, fontSize = 22.sp)
                        }
                    }
                }
            }
        }

        // 2. Change password
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "تغيير كلمة المرور الخاصة بك:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(
                    value = oldPass,
                    onValueChange = { oldPass = it },
                    label = { Text("كلمة المرور الحالية") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it },
                    label = { Text("كلمة المرور الجديدة") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        if (oldPass.isNotEmpty() && newPass.isNotEmpty()) {
                            onUpdatePassword(oldPass, newPass)
                            oldPass = ""
                            newPass = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("تغيير كلمة المرور")
                }
            }
        }

        // 3. User & Permission Management (Admin Only)
        if (currentUser.role == "ADMIN") {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "إدارة صلاحيات الموظفين والمستخدمين:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        TextButton(onClick = { isUserPanelExpanded = !isUserPanelExpanded }) {
                            Text(if (isUserPanelExpanded) "إغلاق" else "أضف موظف")
                        }
                    }

                    AnimatedVisibility(visible = isUserPanelExpanded) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newUsername,
                                onValueChange = { newUsername = it },
                                label = { Text("اسم المستخدم الجديد") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = newPassword,
                                onValueChange = { newPassword = it },
                                label = { Text("كلمة مرور الموظف") },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("صلاحية الحساب:")
                                RadioButton(selected = newUserRole == "EMPLOYEE", onClick = { newUserRole = "EMPLOYEE" })
                                Text("موظف عادي")
                                RadioButton(selected = newUserRole == "ADMIN", onClick = { newUserRole = "ADMIN" })
                                Text("مدير نظام")
                            }
                            Button(
                                onClick = {
                                    if (newUsername.isNotBlank() && newPassword.isNotBlank()) {
                                        // Auto hash
                                        val hash = java.security.MessageDigest.getInstance("SHA-256")
                                            .digest(newPassword.toByteArray())
                                            .joinToString("") { "%02x".format(it) }

                                        onAddUser(
                                            User(
                                                username = newUsername.trim(),
                                                passwordHash = hash,
                                                role = newUserRole,
                                                canAddDrug = true,
                                                canEditDrug = newUserRole == "ADMIN",
                                                canDeleteDrug = newUserRole == "ADMIN",
                                                canDeleteSale = newUserRole == "ADMIN",
                                                mustChangePassword = true
                                            )
                                        )
                                        newUsername = ""
                                        newPassword = ""
                                        isUserPanelExpanded = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("تأكيد تسجيل الموظف")
                            }
                        }
                    }

                    HorizontalDivider()

                    // User table list
                    allUsers.forEach { user ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = user.username, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = if (user.role == "ADMIN") "الرتبة: مدير نظام" else "الرتبة: موظف مبيعات", fontSize = 11.sp, color = Color.Gray)
                            }
                            if (user.username != currentUser.username && user.username != "ali") {
                                IconButton(onClick = { onDeleteUser(user) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Backup & Restore Offline Card
        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "💾 النسخ الاحتياطي واستعادة البيانات (أوفلاين):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "نظراً لأن التطبيق محلي بالكامل، يمكنك حفظ نسخة احتياطية مشفرة كنص آمن، ومشاركتها في الحافظة أو عبر الرسائل لاستعادتها لاحقاً.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Button(
                    onClick = {
                        onExportBackup { backupJson ->
                            // Copy to clipboard
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Pharmacy Backup", backupJson)
                            clipboard.setPrimaryClip(clip)

                            // Trigger android share
                            val sendIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(android.content.Intent.EXTRA_TEXT, backupJson)
                                type = "text/plain"
                            }
                            val shareIntent = android.content.Intent.createChooser(sendIntent, "حفظ ملف نسخة دوائي الاحتياطية")
                            shareIntent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            context.startActivity(shareIntent)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Backup, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إنشاء نسخة احتياطية ومشاركتها")
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text(text = "استيراد نسخة احتياطية من النص:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = backupRestoreJsonText,
                    onValueChange = { backupRestoreJsonText = it },
                    placeholder = { Text("قم بلصق نص النسخة الاحتياطية المصدر هنا...") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
                Button(
                    onClick = {
                        if (backupRestoreJsonText.isNotBlank()) {
                            onImportBackup(backupRestoreJsonText) { success, _ ->
                                if (success) {
                                    backupRestoreJsonText = ""
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("بدء استيراد النسخة الآن")
                }
            }
        }
    }
}

// --- 7. ADD / EDIT DRUG DIALOG ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditDrugDialog(
    drug: Drug?,
    allCompanies: List<Company>,
    allCategories: List<Category>,
    onScanBarcode: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (Drug) -> Unit
) {
    var arabicName by remember { mutableStateOf(drug?.arabicName ?: "") }
    var scientificName by remember { mutableStateOf(drug?.scientificName ?: "") }
    
    // Selection menus
    var companyName by remember { mutableStateOf(drug?.companyName ?: if (allCompanies.isNotEmpty()) allCompanies.first().name else "") }
    var categoryName by remember { mutableStateOf(drug?.categoryName ?: if (allCategories.isNotEmpty()) allCategories.first().name else "") }

    var strength by remember { mutableStateOf(drug?.strength ?: "500 mg") }
    var dosageForm by remember { mutableStateOf(drug?.dosageForm ?: "أقراص") }
    var batchNumber by remember { mutableStateOf(drug?.batchNumber ?: "") }
    
    var productionDate by remember { mutableStateOf(drug?.productionDate ?: "2026-01-01") }
    var expiryDate by remember { mutableStateOf(drug?.expiryDate ?: "2028-12-31") }

    var purchasePriceText by remember { mutableStateOf(drug?.purchasePrice?.toInt()?.toString() ?: "1500") }
    var salePriceText by remember { mutableStateOf(drug?.salePrice?.toInt()?.toString() ?: "2500") }
    var quantityText by remember { mutableStateOf(drug?.quantity?.toString() ?: "50") }
    var minLimitText by remember { mutableStateOf(drug?.minLimit?.toString() ?: "10") }
    
    var barcodeText by remember { mutableStateOf(drug?.barcode ?: "") }
    var notes by remember { mutableStateOf(drug?.notes ?: "") }

    // Dropdowns open state
    var companyDropdownExpanded by remember { mutableStateOf(false) }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    // Sync scanned barcode if present
    LaunchedEffect(scannedBarcodeTemp) {
        if (scannedBarcodeTemp.isNotEmpty()) {
            barcodeText = scannedBarcodeTemp
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.95f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Text(
                        text = if (drug == null) "➕ إضافة دواء جديد للمخزن" else "📝 تعديل بيانات دواء",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Scrollable Fields
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = arabicName,
                            onValueChange = { arabicName = it },
                            label = { Text("اسم الدواء بالعربية *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = scientificName,
                            onValueChange = { scientificName = it },
                            label = { Text("الاسم العلمي *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        // Company drop menu
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = companyName,
                                onValueChange = {},
                                label = { Text("الشركة المصنعة *") },
                                readOnly = true,
                                modifier = Modifier.fillMaxWidth(),
                                trailingIcon = {
                                    IconButton(onClick = { companyDropdownExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                }
                            )
                            DropdownMenu(
                                expanded = companyDropdownExpanded,
                                onDismissRequest = { companyDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                allCompanies.forEach { comp ->
                                    DropdownMenuItem(
                                        text = { Text(comp.name) },
                                        onClick = {
                                            companyName = comp.name
                                            companyDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Category drop menu
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = categoryName,
                                onValueChange = {},
                                label = { Text("التصنيف العلاجي *") },
                                readOnly = true,
                                modifier = Modifier.fillMaxWidth(),
                                trailingIcon = {
                                    IconButton(onClick = { categoryDropdownExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                }
                            )
                            DropdownMenu(
                                expanded = categoryDropdownExpanded,
                                onDismissRequest = { categoryDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                allCategories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat.name) },
                                        onClick = {
                                            categoryName = cat.name
                                            categoryDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = strength,
                                onValueChange = { strength = it },
                                label = { Text("التركيز") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = dosageForm,
                                onValueChange = { dosageForm = it },
                                label = { Text("الشكل الدوائي") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        OutlinedTextField(
                            value = batchNumber,
                            onValueChange = { batchNumber = it },
                            label = { Text("رقم التشغيلة / الوجبة *") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = productionDate,
                                onValueChange = { productionDate = it },
                                label = { Text("تاريخ الإنتاج (YYYY-MM-DD) *") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = expiryDate,
                                onValueChange = { expiryDate = it },
                                label = { Text("تاريخ الانتهاء (YYYY-MM-DD) *") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = purchasePriceText,
                                onValueChange = { purchasePriceText = it },
                                label = { Text("سعر الشراء (د.ع) *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = salePriceText,
                                onValueChange = { salePriceText = it },
                                label = { Text("سعر البيع (د.ع) *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = quantityText,
                                onValueChange = { quantityText = it },
                                label = { Text("الكمية المتوفرة *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = minLimitText,
                                onValueChange = { minLimitText = it },
                                label = { Text("الحد الأدنى للتنبيه *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        // Barcode registration input with CAMERA capture button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = barcodeText,
                                onValueChange = { barcodeText = it },
                                label = { Text("رقم الباركود *") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            Button(
                                onClick = onScanBarcode,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("مسح", fontSize = 12.sp)
                            }
                        }

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("ملاحظات إضافية") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dialog Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (arabicName.isNotBlank() &&
                                    scientificName.isNotBlank() &&
                                    batchNumber.isNotBlank() &&
                                    barcodeText.isNotBlank()
                                ) {
                                    val finalBarcode = barcodeText.trim()
                                    val saved = Drug(
                                        id = drug?.id ?: 0,
                                        arabicName = arabicName.trim(),
                                        scientificName = scientificName.trim(),
                                        companyName = companyName,
                                        categoryName = categoryName,
                                        strength = strength.trim(),
                                        dosageForm = dosageForm.trim(),
                                        batchNumber = batchNumber.trim(),
                                        productionDate = productionDate.trim(),
                                        expiryDate = expiryDate.trim(),
                                        purchasePrice = purchasePriceText.toDoubleOrNull() ?: 0.0,
                                        salePrice = salePriceText.toDoubleOrNull() ?: 0.0,
                                        quantity = quantityText.toIntOrNull() ?: 0,
                                        minLimit = minLimitText.toIntOrNull() ?: 10,
                                        barcode = finalBarcode,
                                        notes = notes.trim(),
                                        isArchived = drug?.isArchived ?: false
                                    )
                                    onSave(saved)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("حفظ الدواء")
                        }

                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء")
                        }
                    }
                }
            }
        }
    }
}
