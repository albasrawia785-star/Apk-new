package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.BarcodeScannerView
import com.example.ui.components.VisualBarcode
import com.example.viewmodel.AppViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: AppViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Observe DB States
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val mustChangePasswordUser by viewModel.mustChangePasswordUser.collectAsStateWithLifecycle()

    val allDrugs by viewModel.allDrugs.collectAsStateWithLifecycle()
    val allCompanies by viewModel.allCompanies.collectAsStateWithLifecycle()
    val allCategories by viewModel.allCategories.collectAsStateWithLifecycle()
    val allSalesBills by viewModel.allSalesBills.collectAsStateWithLifecycle()
    val allLogs by viewModel.allLogs.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()

    val pharmacyName by viewModel.pharmacyName.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val logoIndex by viewModel.logoIndex.collectAsStateWithLifecycle()

    // Navigation Tab state
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Dashboard, 1: Drugs, 2: POS/Scanner, 3: Reports, 4: Settings

    // Scan state
    var showScannerForAction by remember { mutableStateOf<ScannerAction?>(null) } // null, SELL, ADD, SEARCH, ADD_DRUG_BARCODE

    // Alert Dialogs
    var showAddDrugDialog by remember { mutableStateOf(false) }
    var drugToEdit by remember { mutableStateOf<Drug?>(null) }

    // Observe System Toast Messages
    LaunchedEffect(Unit) {
        viewModel.uiMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                actionLabel = "حسناً",
                duration = SnackbarDuration.Short
            )
        }
    }

    // Force Arabic (RTL) Layout Direction
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (currentUser != null) {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = getPharmacyLogoEmoji(logoIndex),
                                    fontSize = 28.sp
                                )
                                Column {
                                    Text(
                                        text = pharmacyName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "المستخدم الحالي: ${currentUser?.username} (${if (currentUser?.role == "ADMIN") "مدير" else "موظف"})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        },
                        actions = {
                            // Dark Mode Toggle
                            IconButton(onClick = { viewModel.toggleDarkMode(!isDarkMode) }) {
                                Icon(
                                    imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Theme Toggle"
                                )
                            }
                            // Logout Button
                            IconButton(onClick = { viewModel.logout() }) {
                                Icon(
                                    imageVector = Icons.Default.Logout,
                                    contentDescription = "Logout",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                        )
                    )
                }
            },
            bottomBar = {
                if (currentUser != null) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                            label = { Text("لوحة التحكم", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.Medication, contentDescription = "Drugs") },
                            label = { Text("المستودع", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.PointOfSale, contentDescription = "POS") },
                            label = { Text("مسح سريع", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 3,
                            onClick = { selectedTab = 3 },
                            icon = { Icon(Icons.Default.Assessment, contentDescription = "Reports") },
                            label = { Text("التقارير", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 4,
                            onClick = { selectedTab = 4 },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("الإعدادات والنسخ", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (currentUser == null) {
                    // Login Screen Layout (includes Force password change overlay)
                    LoginView(
                        mustChangePasswordUser = mustChangePasswordUser,
                        onLogin = { user, pass -> viewModel.login(user, pass) },
                        onChangePassword = { user, newPass -> viewModel.changePassword(user, newPass) }
                    )
                } else {
                    // Main app contents based on active tab
                    when (selectedTab) {
                        0 -> DashboardScreen(
                            allDrugs = allDrugs,
                            allCompanies = allCompanies,
                            allCategories = allCategories,
                            allSalesBills = allSalesBills,
                            onQuickSellClick = { showScannerForAction = ScannerAction.SELL }
                        )
                        1 -> DrugsScreen(
                            allDrugs = allDrugs,
                            allCompanies = allCompanies,
                            allCategories = allCategories,
                            currentUser = currentUser!!,
                            onAddDrugClick = { showAddDrugDialog = true },
                            onEditDrugClick = { drug ->
                                drugToEdit = drug
                                showAddDrugDialog = true
                            },
                            onDeleteDrugClick = { drug -> viewModel.deleteDrug(drug) },
                            onGenerateBarcode = { drugId -> viewModel.generateUniqueBarcodeForDrug(drugId) {} }
                        )
                        2 -> POSScreen(
                            allDrugs = allDrugs,
                            onActionSelected = { action -> showScannerForAction = action }
                        )
                        3 -> ReportsScreen(
                            allDrugs = allDrugs,
                            allSalesBills = allSalesBills,
                            allLogs = allLogs,
                            currentUser = currentUser!!,
                            onDeleteSaleBill = { bill -> viewModel.deleteSaleBill(bill) }
                        )
                        4 -> SettingsScreen(
                            allUsers = allUsers,
                            currentUser = currentUser!!,
                            pharmacyName = pharmacyName,
                            logoIndex = logoIndex,
                            onUpdatePharmacyName = { viewModel.updatePharmacyName(it) },
                            onUpdateLogo = { viewModel.updateLogoIndex(it) },
                            onAddUser = { user -> viewModel.registerUser(user) },
                            onUpdateUser = { user -> viewModel.updateUser(user) },
                            onDeleteUser = { user -> viewModel.deleteUser(user) },
                            onExportBackup = { callback -> viewModel.exportLocalBackup(callback) },
                            onImportBackup = { json, cb -> viewModel.importLocalBackup(json, cb) },
                            onUpdatePassword = { oldPass, newPass ->
                                scope.launch {
                                    val user = repositoryUser(viewModel, currentUser!!.username)
                                    if (user != null && user.passwordHash == viewModel.hashPassword(oldPass)) {
                                        viewModel.changePassword(user.username, newPass)
                                    } else {
                                        snackbarHostState.showSnackbar("كلمة المرور القديمة غير صحيحة!")
                                    }
                                }
                            }
                        )
                    }
                }

                // Handle Camera Scanning Overlay Actions
                if (showScannerForAction != null) {
                    var scannerResolvedDrug by remember { mutableStateOf<Drug?>(null) }
                    var resolvedErrorText by remember { mutableStateOf("") }
                    var actionQuantityText by remember { mutableStateOf("1") }
                    var actionPriceText by remember { mutableStateOf("") }

                    BarcodeScannerView(
                        allAvailableDrugs = allDrugs.filter { !it.isArchived },
                        onBarcodeScanned = { scannedBarcode ->
                            viewModel.playBeep()
                            viewModel.triggerVibration()

                            scope.launch {
                                when (showScannerForAction) {
                                    ScannerAction.SELL -> {
                                        val drug = allDrugs.find { it.barcode == scannedBarcode }
                                        if (drug == null) {
                                            resolvedErrorText = "الدواء غير موجود."
                                            scannerResolvedDrug = null
                                        } else {
                                            scannerResolvedDrug = drug
                                            resolvedErrorText = ""
                                            actionQuantityText = "1"
                                        }
                                    }
                                    ScannerAction.ADD -> {
                                        val drug = allDrugs.find { it.barcode == scannedBarcode }
                                        if (drug == null) {
                                            resolvedErrorText = "الدواء غير موجود في قاعدة البيانات."
                                            scannerResolvedDrug = null
                                        } else {
                                            scannerResolvedDrug = drug
                                            resolvedErrorText = ""
                                            actionQuantityText = "10"
                                            actionPriceText = drug.purchasePrice.toInt().toString()
                                        }
                                    }
                                    ScannerAction.SEARCH -> {
                                        val drug = allDrugs.find { it.barcode == scannedBarcode }
                                        if (drug == null) {
                                            resolvedErrorText = "هذا الدواء غير موجود في قاعدة البيانات."
                                            scannerResolvedDrug = null
                                        } else {
                                            scannerResolvedDrug = drug
                                            resolvedErrorText = ""
                                        }
                                    }
                                    ScannerAction.ADD_DRUG_BARCODE -> {
                                        // Auto-inject scanned barcode into add-drug dialog if open
                                        scannedBarcodeTemp = scannedBarcode
                                        showScannerForAction = null
                                    }
                                    else -> {}
                                }
                            }
                        },
                        onClose = {
                            showScannerForAction = null
                            scannerResolvedDrug = null
                            resolvedErrorText = ""
                        }
                    )

                    // Overlay Dialog with Scanned details for transactional verification
                    if (scannerResolvedDrug != null || resolvedErrorText.isNotEmpty()) {
                        Dialog(
                            onDismissRequest = {
                                scannerResolvedDrug = null
                                resolvedErrorText = ""
                            },
                            properties = DialogProperties(usePlatformDefaultWidth = false)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.6f)),
                                contentAlignment = Alignment.Center
                            ) {
                                ElevatedCard(
                                    modifier = Modifier
                                        .fillMaxWidth(0.9f)
                                        .padding(16.dp),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        if (resolvedErrorText.isNotEmpty()) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(54.dp)
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text(
                                                text = resolvedErrorText,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.error,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(24.dp))
                                            Button(
                                                onClick = {
                                                    resolvedErrorText = ""
                                                },
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("إعادة المحاولة / إغلاق")
                                            }
                                        } else if (scannerResolvedDrug != null) {
                                            val d = scannerResolvedDrug!!
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(48.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = d.arabicName,
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                text = "الاسم العلمي: ${d.scientificName}",
                                                fontSize = 14.sp,
                                                color = Color.Gray,
                                                textAlign = TextAlign.Center
                                            )
                                            Text(
                                                text = "الشركة: ${d.companyName} | المادة: ${d.dosageForm}",
                                                fontSize = 12.sp,
                                                color = Color.Gray,
                                                textAlign = TextAlign.Center
                                            )

                                            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                                            when (showScannerForAction) {
                                                ScannerAction.SELL -> {
                                                    Text(
                                                        text = "سعر البيع المفرد: ${formatIraqiDinar(d.salePrice)}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 16.sp
                                                    )
                                                    Text(
                                                        text = "الكمية المتوفرة بالمخزن: ${d.quantity}",
                                                        color = if (d.quantity < d.minLimit) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp
                                                    )

                                                    Spacer(modifier = Modifier.height(16.dp))

                                                    OutlinedTextField(
                                                        value = actionQuantityText,
                                                        onValueChange = { actionQuantityText = it },
                                                        label = { Text("الكمية المطلوبة للبيع") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.fillMaxWidth()
                                                    )

                                                    val q = actionQuantityText.toIntOrNull() ?: 1
                                                    val finalTotal = d.salePrice * q
                                                    Spacer(modifier = Modifier.height(12.dp))
                                                    Text(
                                                        text = "الإجمالي: ${formatIraqiDinar(finalTotal)}",
                                                        fontSize = 18.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = MaterialTheme.colorScheme.secondary
                                                    )

                                                    Spacer(modifier = Modifier.height(20.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Button(
                                                            onClick = {
                                                                viewModel.sellDrugByBarcode(d.barcode, q) { success, _, _ ->
                                                                    if (success) {
                                                                        scannerResolvedDrug = null
                                                                        showScannerForAction = null
                                                                    }
                                                                }
                                                            },
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Text("تأكيد عملية البيع")
                                                        }
                                                        OutlinedButton(
                                                            onClick = { scannerResolvedDrug = null },
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Text("إلغاء")
                                                        }
                                                    }
                                                }
                                                ScannerAction.ADD -> {
                                                    Text(
                                                        text = "سعر الشراء الحالي: ${formatIraqiDinar(d.purchasePrice)}",
                                                        fontSize = 14.sp
                                                    )
                                                    Text(
                                                        text = "الكمية الحالية: ${d.quantity}",
                                                        fontSize = 14.sp
                                                    )

                                                    Spacer(modifier = Modifier.height(16.dp))

                                                    OutlinedTextField(
                                                        value = actionQuantityText,
                                                        onValueChange = { actionQuantityText = it },
                                                        label = { Text("الكمية المشتراة المضافة") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.fillMaxWidth()
                                                    )

                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    OutlinedTextField(
                                                        value = actionPriceText,
                                                        onValueChange = { actionPriceText = it },
                                                        label = { Text("سعر الشراء الجديد (د.ع) - اختياري") },
                                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                        modifier = Modifier.fillMaxWidth()
                                                    )

                                                    Spacer(modifier = Modifier.height(20.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Button(
                                                            onClick = {
                                                                val q = actionQuantityText.toIntOrNull() ?: 0
                                                                val p = actionPriceText.toDoubleOrNull()
                                                                if (q > 0) {
                                                                    viewModel.addStockQuantityByBarcode(d.barcode, q, p) { success, _, _ ->
                                                                        if (success) {
                                                                            scannerResolvedDrug = null
                                                                            showScannerForAction = null
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Text("تأكيد الإضافة للمخزن")
                                                        }
                                                        OutlinedButton(
                                                            onClick = { scannerResolvedDrug = null },
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Text("إلغاء")
                                                        }
                                                    }
                                                }
                                                ScannerAction.SEARCH -> {
                                                    VisualBarcode(barcode = d.barcode, modifier = Modifier.fillMaxWidth().height(100.dp))
                                                    Spacer(modifier = Modifier.height(12.dp))

                                                    Text("الكمية المتوفرة: ${d.quantity} حبة", fontWeight = FontWeight.Bold)
                                                    Text("سعر البيع: ${formatIraqiDinar(d.salePrice)}")
                                                    Text("تاريخ الصلاحية: ${d.expiryDate}")
                                                    Text("الموقع/الملاحظات: ${d.notes}")

                                                    Spacer(modifier = Modifier.height(24.dp))
                                                    Button(
                                                        onClick = { scannerResolvedDrug = null },
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Text("موافق")
                                                    }
                                                }
                                                else -> {}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Add / Edit Drug Dialog Layout
                if (showAddDrugDialog) {
                    AddEditDrugDialog(
                        drug = drugToEdit,
                        allCompanies = allCompanies,
                        allCategories = allCategories,
                        onScanBarcode = {
                            showScannerForAction = ScannerAction.ADD_DRUG_BARCODE
                        },
                        onDismiss = {
                            showAddDrugDialog = false
                            drugToEdit = null
                            scannedBarcodeTemp = ""
                        },
                        onSave = { savedDrug ->
                            if (drugToEdit == null) {
                                viewModel.addDrug(savedDrug) { success ->
                                    if (success) {
                                        showAddDrugDialog = false
                                        scannedBarcodeTemp = ""
                                    }
                                }
                            } else {
                                viewModel.updateDrug(savedDrug) { success ->
                                    if (success) {
                                        showAddDrugDialog = false
                                        drugToEdit = null
                                        scannedBarcodeTemp = ""
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

enum class ScannerAction {
    SELL, ADD, SEARCH, ADD_DRUG_BARCODE
}

// Global placeholder to sync scanned barcode back into input field when adding a drug
var scannedBarcodeTemp by mutableStateOf("")

private suspend fun repositoryUser(viewModel: AppViewModel, username: String): User? {
    // ViewModel shares list of users
    return viewModel.allUsers.value.find { it.username == username }
}

// Get logo emoji based on chosen index
fun getPharmacyLogoEmoji(index: Int): String {
    return when (index) {
        0 -> "💊"
        1 -> "🏥"
        2 -> "🧪"
        3 -> "🩺"
        4 -> "💚"
        else -> "💊"
    }
}

// Helpers for Iraqi Dinar Formatting
fun formatIraqiDinar(amount: Double): String {
    val format = NumberFormat.getInstance(Locale("ar", "IQ"))
    return "${format.format(amount)} د.ع"
}

// Time/Date Formatting helper
fun formatTimestamp(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("ar"))
    return sdf.format(Date(timestamp))
}

// Check if a date string is expired compared to current time
fun isMedicineExpired(dateStr: String): Boolean {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val expiryDate = sdf.parse(dateStr)
        expiryDate != null && expiryDate.before(Date())
    } catch (e: Exception) {
        false
    }
}
