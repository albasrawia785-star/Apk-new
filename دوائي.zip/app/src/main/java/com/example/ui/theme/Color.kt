package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val PrimaryLight = Color(0xFF006A6A)
val SecondaryLight = Color(0xFF004D4D)
val TertiaryLight = Color(0xFF002020)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)

// Dark Colors
val PrimaryDark = Color(0xFF4FD1D1)
val SecondaryDark = Color(0xFF319795)
val TertiaryDark = Color(0xFF234E52)
val BackgroundDark = Color(0xFF0A1112)
val SurfaceDark = Color(0xFF111D1E)

